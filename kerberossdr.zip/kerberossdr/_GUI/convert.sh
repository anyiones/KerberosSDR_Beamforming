#!/bin/sh
pyuic4 Main_hydra_dev.ui -o hydra_main_window_layout.py
