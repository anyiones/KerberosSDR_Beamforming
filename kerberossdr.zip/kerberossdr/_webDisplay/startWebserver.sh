sudo php -S 10.42.0.1:80
